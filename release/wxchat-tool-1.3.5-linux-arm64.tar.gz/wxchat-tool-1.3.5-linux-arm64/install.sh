#!/usr/bin/env bash
set -euo pipefail
TOOL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications"
ICONS="$HOME/.local/share/icons/hicolor"
for s in 48 128 256 512; do
  d="$ICONS/${s}x${s}/apps"; mkdir -p "$d"
  case $s in 48) f=icon-48.png;; 128) f=icon-128.png;; 256) f=icon.png;; 512) f=icon-512.png;; esac
  cp -f "$TOOL_DIR/assets/$f" "$d/wxchat-tool.png"
done
cp -f "$TOOL_DIR/bin/wxchat-tool" "$HOME/.local/bin/wxchat-tool"
cp -f "$TOOL_DIR/bin/wxchat-gui" "$HOME/.local/bin/wxchat-gui"
cat > "$HOME/.local/share/applications/wxchat-tool.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=微数全解
Name[en]=WeChat DataKit
Comment=解密并导出本机微信 4.x 本地数据库（图形界面）
Exec=$HOME/.local/bin/wxchat-gui
Icon=$ICONS/256x256/apps/wxchat-tool.png
Terminal=false
Categories=Utility;
EOF
chmod +x "$HOME/.local/bin/wxchat-tool" "$HOME/.local/bin/wxchat-gui" "$HOME/.local/share/applications/wxchat-tool.desktop"
gtk-update-icon-cache -f "$ICONS" 2>/dev/null || true
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
echo "微数全解 WeChat DataKit 安装完成"
