# 微信数据全解工具 (wxchat-tool)

Linux 上针对微信 4.x 本地数据的全量解密与导出工具。

## 功能

- `scan` — 从运行中的微信进程内存提取 WCDB 数据库密钥（无需重新登录）
- `decrypt` — 解密所有数据库，并合并 WAL 增量页
- `all` — `scan` + `decrypt` + `export` 一步完成
- `export` — 导出联系人、会话、聊天记录（CSV / JSONL / HTML）
- `export --chatlab` / `chats --chatlab` — 按会话导出 ChatLab 标准 JSONL（可直接导入 ChatLab 分析）
- `images` — 解密 `.dat` 图片（旧 XOR / V1 / V2）

## ChatLab 导入

本工具可把微信聊天记录转换为 [ChatLab 标准格式 v0.0.2](https://docs.chatlab.fun/standard/chatlab-format) 的 JSONL 文件，每个会话一个文件，可直接被 [ChatLab](https://github.com/ChatLab/ChatLab) 识别与分析：

```bash
# 全部会话
wxchat-tool export --chatlab --out ~/wxchat-output

# 指定会话
wxchat-tool chats --chatlab --usernames 'wxid_xxx,123@chatroom' --out ~/wxchat-output
```

输出位于 `<out>/export/chatlab/*.jsonl`。可用 ChatLab CLI 校验：

```bash
clb validate "<out>/export/chatlab/某会话.jsonl" --json
clb import "<out>/export/chatlab/某会话.jsonl" --dry-run --json
```

## 环境要求

- Linux (本机验证为 ARM64，x86_64 同样适用)
- Python 3.10+
- 微信 4.x 正在运行且已登录
- 密钥提取需要 root 或 CAP_SYS_PTRACE

## 安装

```bash
cd /path/to/wxchat-tool
bash install.sh
```

安装后在 `~/.local/bin/wxchat-tool` 生成命令，并在
`~/.local/share/applications/wxchat-tool.desktop` 生成桌面启动器。

## 使用

### 图形界面

```bash
wxchat-gui
```

或从应用菜单启动“微数全解”。界面中可自定义：

- 微信数据库目录 (db_storage)
- 附件目录 (msg/attach)
- 输出目录
- 图片 AES Key / XOR Key（可选，留空自动提取）

### 命令行

```bash
# 全自动：提取密钥 + 解密 + 导出
wxchat-tool all --out ~/wxchat-output

# 指定数据目录（默认自动检测）
wxchat-tool all --db-dir ~/Documents/xwechat_files/<wxid>/db_storage

# 仅解密（已有密钥文件）
wxchat-tool decrypt --keys ~/wxchat-output/all_keys.json --out ~/wxchat-output

# 仅导出
wxchat-tool export --out ~/wxchat-output

# 解密图片（V2 需先在微信中点击查看几张图片，让密钥进入内存）
wxchat-tool images --attach-dir ~/Documents/xwechat_files/<wxid>/msg/attach
```

## 输出结构

```
output/
├── all_keys.json      # 每个数据库的 enc_key 与 salt
├── decrypted/         # 解密后的 SQLite 数据库（已合并 WAL）
├── images/            # 解密后的图片
└── export/
    ├── contacts.csv
    ├── sessions.csv
    ├── messages.jsonl # 全部聊天记录
    └── index.html     # 浏览页
```

## 说明与边界

- 本工具仅用于解密**用户自己的**微信本地数据。
- 少数迁移/遗留库（如 `migrate/unspportmsg.db`）可能使用历史登录态密钥，
  当前进程内存中没有对应密钥，会标记为 SKIP，不影响聊天主体。
- 图片 V2 格式的 AES 密钥来自微信进程内存，通常需要先在微信中打开几张图片。

## 原理

微信 4.x 使用 SQLCipher 4 加密本地数据库（AES-256-CBC + HMAC-SHA512，
PBKDF2-HMAC-SHA512 256,000 轮）。WCDB 会把派生后的 raw key 以
`x'<64位enc_key><32位salt>'` 的形式缓存在进程内存中。本工具通过
`/proc/<pid>/mem` 扫描该模式，并用数据库 page 1 的 HMAC 校验确认，
再用 per-DB 密钥逐页解密主库与 WAL。
